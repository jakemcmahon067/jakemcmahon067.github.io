import { Tour } from '../types';

interface CountryData {
  id: string;
  name: string;
  description: string;
  imageUrl: string;
  tours: Tour[];
}

export const countries: CountryData[] = [
  {
    id: 'greece',
    name: 'Greece',
    description: 'Discover ancient ruins, stunning islands, and Mediterranean charm in Greece. From the Acropolis in Athens to the white-washed buildings of Santorini, Greece offers a perfect blend of history, culture, and natural beauty.',
    imageUrl: 'https://images.unsplash.com/photo-1533105079780-92b9be482077',
    tours: [
      {
        name: 'Ancient Athens Explorer',
        description: 'Explore the historic sites of Athens, including the Acropolis and Parthenon.',
        price: 89,
        duration: '1 Day'
      },
      {
        name: 'Greek Islands Hopping',
        description: 'Visit Santorini, Mykonos, and Crete in this comprehensive island tour.',
        price: 1299,
        duration: '7 Days'
      },
      {
        name: 'Delphi & Meteora Adventure',
        description: 'Journey to the ancient sanctuary of Delphi and the monasteries of Meteora.',
        price: 199,
        duration: '2 Days'
      }
    ]
  },
  {
    id: 'italy',
    name: 'Italy',
    description: 'Experience la dolce vita in Italy, where art, history, and cuisine create an unforgettable journey. From the Roman Colosseum to the canals of Venice, every corner tells a story of cultural richness and artistic excellence.',
    imageUrl: 'https://images.unsplash.com/photo-1523906834658-6e24ef2386f9',
    tours: [
      {
        name: 'Rome Highlights',
        description: 'Visit the Colosseum, Vatican Museums, and Roman Forum.',
        price: 129,
        duration: '1 Day'
      },
      {
        name: 'Tuscany Wine Tour',
        description: 'Explore vineyards and medieval towns in the Tuscan countryside.',
        price: 179,
        duration: '1 Day'
      },
      {
        name: 'Venice & Florence Discovery',
        description: 'Experience the beauty of Venice and the Renaissance art of Florence.',
        price: 899,
        duration: '5 Days'
      }
    ]
  },
  {
    id: 'japan',
    name: 'Japan',
    description: 'Immerse yourself in the fascinating blend of ancient traditions and modern innovation in Japan. From peaceful temples to bustling city streets, Japan offers a unique cultural experience unlike anywhere else.',
    imageUrl: 'https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e',
    tours: [
      {
        name: 'Tokyo Tech & Tradition',
        description: 'Experience modern Tokyo and traditional temples and gardens.',
        price: 149,
        duration: '1 Day'
      },
      {
        name: 'Kyoto Cultural Journey',
        description: 'Visit ancient temples, participate in a tea ceremony, and explore geisha districts.',
        price: 199,
        duration: '2 Days'
      },
      {
        name: 'Mount Fuji & Hakone',
        description: 'Visit Mount Fuji, ride the bullet train, and relax in hot springs.',
        price: 249,
        duration: '2 Days'
      }
    ]
  }
];