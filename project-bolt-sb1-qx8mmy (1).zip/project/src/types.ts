export interface Tour {
  name: string;
  description: string;
  price: number;
  duration: string;
}