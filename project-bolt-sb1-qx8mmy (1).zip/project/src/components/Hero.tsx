import { ArrowDown } from 'lucide-react';

export default function Hero() {
  return (
    <div id="home" className="relative h-screen flex items-center justify-center">
      <img
        src="https://images.unsplash.com/photo-1488085061387-422e29b40080"
        alt="Travel Hero"
        className="absolute inset-0 w-full h-full object-cover"
      />
      <div className="absolute inset-0 bg-black bg-opacity-50" />
      <div className="relative text-center text-white px-4">
        <h1 className="text-5xl md:text-6xl font-bold mb-6">Discover the World</h1>
        <p className="text-xl md:text-2xl mb-8">Explore the beauty of Greece, Italy, and Japan</p>
        <a
          href="#greece"
          className="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-full transition"
        >
          Start Exploring
          <ArrowDown className="h-5 w-5" />
        </a>
      </div>
    </div>
  );
}