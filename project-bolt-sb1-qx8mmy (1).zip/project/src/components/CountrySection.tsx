import { Tour } from '../types';

interface CountrySectionProps {
  id: string;
  name: string;
  description: string;
  imageUrl: string;
  tours: Tour[];
}

export default function CountrySection({ id, name, description, imageUrl, tours }: CountrySectionProps) {
  return (
    <section id={id} className="py-20 scroll-mt-16">
      <div className="max-w-7xl mx-auto px-4">
        <div className="grid md:grid-cols-2 gap-8 items-center">
          <div className="relative h-[400px] rounded-lg overflow-hidden">
            <img
              src={imageUrl}
              alt={name}
              className="absolute inset-0 w-full h-full object-cover transform hover:scale-105 transition duration-500"
            />
          </div>
          
          <div>
            <h2 className="text-4xl font-bold mb-4">{name}</h2>
            <p className="text-gray-600 mb-6">{description}</p>
            
            <div className="space-y-4">
              <h3 className="text-2xl font-semibold">Popular Tours</h3>
              {tours.map((tour, index) => (
                <div
                  key={index}
                  className="bg-white p-4 rounded-lg shadow-md hover:shadow-lg transition"
                >
                  <h4 className="text-xl font-semibold mb-2">{tour.name}</h4>
                  <p className="text-gray-600 mb-2">{tour.description}</p>
                  <div className="flex justify-between items-center">
                    <span className="text-blue-600 font-bold">${tour.price}</span>
                    <span className="text-gray-500">{tour.duration}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}