import Navbar from './components/Navbar';
import Hero from './components/Hero';
import CountrySection from './components/CountrySection';
import { countries } from './data/countries';

function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <Hero />
      
      <main>
        {countries.map((country) => (
          <CountrySection
            key={country.id}
            id={country.id}
            name={country.name}
            description={country.description}
            imageUrl={country.imageUrl}
            tours={country.tours}
          />
        ))}
      </main>

      <footer className="bg-gray-800 text-white py-8">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <p>© 2024 WorldWanderer. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

export default App;